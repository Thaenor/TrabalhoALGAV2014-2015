% 4. Pontos de interesse
/*ponto de interesse pdi(estacaoEmQueSeEncontra, nomeDoPontoDeInteresse,horaAbertura,minutoAbertura,horaFecho,minutoFecho).*/
%linha 1
pdi('La Defense Grande Arche','Grande Arche',8,0,20,0).
pdi('Palais Royal - Musee du Louvre','Musee du Louvre',8,0,20,0).
pdi('Palais Royal - Musee du Louvre','Palais Royal',8,0,20,0).
pdi('Bastille','Bastille',8,0,20,0).
pdi('Pyramides','Pyramides',8,0,20,0).
pdi('Place Monge Jardin des Plantes - Arenes de Lutece','Jardin des Plantes',8,0,20,0).
pdi('Solferino – Musee dOrsay','Musee dOrsay',8,0,20,0).
pdi('Chateau de Vincennes','Chateau de Vincennes',8,0,20,0).
pdi('La Chapelle','La Chapelle',8,0,20,0).
pdi('Gare du Nord','Gare du Nord',8,0,20,0).
pdi('Pablo Picasso Prefecture','Pablo Picasso Prefecture',8,0,20,0).
pdi('Bir-Hakeim Tour Eiffel','Tour Eiffel',8,0,20,0).
pdi('Fort d’Aubervilliers','Fort d’Aubervilliers',8,0,20,0).
pdi('Jardin des Plantes - Arenes de Lutece','Jardin des Plantes',8,0,20,0).
pdi('Maison Blanche','Maison Blanche',8,0,20,0).
pdi('Pierre et Marie Curie','Pierre et Marie Curie',8,0,20,0).
pdi('Saint-Sebastien - Froissart','Saint-Sebastien - Froissart',8,0,20,0).
pdi('Notre-Dame-de-Lorette','Notre-Dame-de-Lorette',8,0,20,0).
pdi('Champs-elysees - Clemenceau Grand Palais','Champs-elysees',8,0,20,0).
pdi('Champs-elysees - Clemenceau Grand Palais','Clemenceau Grand Palais',8,0,20,0).
pdi('Bibliotheque François Mitterrand','Bibliotheque François Mitterrand',8,0,20,0).