% Trabalho Prático de ALGAV %
% 	  Francisco Santos      %
% 		  Rui Silva 		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Base de conhecimento

:- consult(horarios).
:- consult(linhas).
:- consult(pdi).
:- consult(pesquisas).
:- consult(geradores).
:- gera_cruzamentos.
:- gera_ligacoes.
:- gera_estacoes.
:- gera_estacoes_linhas.